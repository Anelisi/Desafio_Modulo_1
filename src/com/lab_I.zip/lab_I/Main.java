package com.lab_I;

public class Main {

    public static void main(String[] args) {
        Cidade cidade = new Cidade();
        cidade.criarCidade();
    }
}




// SE PRECISAR JÁ TEM PRONTO...

        /*Aluno aluno = new Aluno();
        aluno.criarAluno();*/


//Cidade cidade = new Cidade();
//cidade.criarCidade();


        /*Cidade c1 = new Cidade( "Porto Alegre", "RS");

        Aluno a1 = new Aluno("Anelsi","14/04/1987", "anelisi@unisinos.com", "123456");
        Aluno a2 = new Aluno("Arthur", "30/10/1986", "arthur@unisinos.com", "654321");

        Cidade c2 = new Cidade("São Borja", "RS");

        Aluno a3 = new Aluno("Eliane", "10/03/1960", "eliane@unisinos.com",  "456789");
        Aluno a4 = new Aluno("Leides","15/04/1987" ,"leides@unisinos.com" , "987654");

        a1.alterarSenha();

        c1.exibeDados();
        c2.exibeDados();*/


